"use client"

import type React from "react"
import { useState } from "react"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { Shield, User, Lock } from "lucide-react"
import { useAuth } from "@/lib/auth-context"

export default function LoginPage() {
  const [username, setUsername] = useState("")
  const [password, setPassword] = useState("")
  const [error, setError] = useState("")
  const [loading, setLoading] = useState(false)
  const router = useRouter()
  const { login } = useAuth()

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setLoading(true)
    setError("")

    try {
      const success = await login(username, password)
      if (success) {
        router.push("/dashboard")
      } else {
        setError("Invalid username or password")
      }
    } catch (error) {
      setError("An error occurred during login")
    } finally {
      setLoading(false)
    }
  }

  // Quick login function for demo
  const quickLogin = async (demoUsername: string, demoPassword: string) => {
    setLoading(true)
    setError("")

    try {
      const success = await login(demoUsername, demoPassword)
      if (success) {
        router.push("/dashboard")
      } else {
        setError("Login failed")
      }
    } catch (error) {
      setError("Login failed")
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900 p-4">
      <Card className="w-full max-w-md">
        <CardHeader className="text-center">
          <div className="flex justify-center mb-4">
            <Shield className="h-12 w-12 text-blue-600" />
          </div>
          <CardTitle className="text-2xl font-bold">Military Asset Management</CardTitle>
          <CardDescription>Secure access to military asset tracking system</CardDescription>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="username">Username</Label>
              <div className="relative">
                <User className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
                <Input
                  id="username"
                  type="text"
                  placeholder="Enter username"
                  value={username}
                  onChange={(e) => setUsername(e.target.value)}
                  className="pl-10"
                  required
                  disabled={loading}
                />
              </div>
            </div>
            <div className="space-y-2">
              <Label htmlFor="password">Password</Label>
              <div className="relative">
                <Lock className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
                <Input
                  id="password"
                  type="password"
                  placeholder="Enter password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  className="pl-10"
                  required
                  disabled={loading}
                />
              </div>
            </div>
            {error && (
              <Alert variant="destructive">
                <AlertDescription>{error}</AlertDescription>
              </Alert>
            )}
            <Button type="submit" className="w-full" disabled={loading}>
              {loading ? "Signing in..." : "Sign In"}
            </Button>
          </form>

          <div className="mt-6 p-4 bg-gray-50 rounded-lg">
            <h3 className="font-semibold text-sm mb-3">Demo Credentials - Click to Auto-Fill:</h3>
            <div className="space-y-2">
              <Button
                variant="outline"
                size="sm"
                className="w-full text-left justify-start"
                onClick={() => {
                  setUsername("admin")
                  setPassword("admin123")
                }}
                disabled={loading}
              >
                <strong>Admin:</strong>&nbsp;admin / admin123
              </Button>
              <Button
                variant="outline"
                size="sm"
                className="w-full text-left justify-start"
                onClick={() => {
                  setUsername("cmd_liberty")
                  setPassword("admin123")
                }}
                disabled={loading}
              >
                <strong>Base Commander:</strong>&nbsp;cmd_liberty / admin123
              </Button>
              <Button
                variant="outline"
                size="sm"
                className="w-full text-left justify-start"
                onClick={() => {
                  setUsername("log_liberty")
                  setPassword("admin123")
                }}
                disabled={loading}
              >
                <strong>Logistics Officer:</strong>&nbsp;log_liberty / admin123
              </Button>
            </div>

            <div className="mt-4 p-3 bg-blue-50 rounded border border-blue-200">
              <h4 className="font-semibold text-xs text-blue-800 mb-2">Manual Login Instructions:</h4>
              <div className="text-xs text-blue-700 space-y-1">
                <div>
                  <strong>Username:</strong> admin, cmd_liberty, or log_liberty
                </div>
                <div>
                  <strong>Password:</strong> admin123 (for all accounts)
                </div>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
