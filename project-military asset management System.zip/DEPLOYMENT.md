# Military Asset Management System - Deployment Guide

## Quick Deployment Options

### Option 1: Vercel (Recommended)
1. Download the code from v0
2. Push to GitHub repository
3. Connect to Vercel
4. Deploy automatically

### Option 2: Render
1. Download the code
2. Create new Web Service on Render
3. Connect your repository
4. Set build command: `npm run build`
5. Set start command: `npm start`

### Option 3: Railway
1. Download the code
2. Connect GitHub repo to Railway
3. Deploy with one click

## Environment Variables
Set these in your hosting platform:

\`\`\`
NEXTAUTH_SECRET=your-secret-key-here
NEXTAUTH_URL=https://your-domain.com
\`\`\`

## Database Setup (Optional)
For production, replace mock data with real database:

### PostgreSQL Setup
1. Create PostgreSQL database
2. Run the SQL scripts in `/scripts/` folder
3. Update connection strings

### Supabase Setup
1. Create Supabase project
2. Run SQL scripts in Supabase SQL editor
3. Update environment variables

## Build Commands
\`\`\`bash
# Install dependencies
npm install

# Build for production
npm run build

# Start production server
npm start
\`\`\`

## Features Included
- ✅ Complete authentication system
- ✅ Role-based access control (Admin, Base Commander, Logistics Officer)
- ✅ Dashboard with metrics and charts
- ✅ Purchase management
- ✅ Transfer tracking between bases
- ✅ Asset assignments and expenditures
- ✅ Responsive design for mobile/tablet/desktop
- ✅ Database schema with sample data

## Demo Credentials
- Admin: admin / admin123
- Base Commander: cmd_liberty / admin123
- Logistics Officer: log_liberty / admin123

## Tech Stack
- Frontend: Next.js 14, React, TypeScript
- UI: Tailwind CSS, shadcn/ui
- Authentication: Custom auth system
- Database: PostgreSQL (schema provided)
- Deployment: Vercel, Render, Railway compatible
